# aws-codedeploy-linux
This is a simple website that can be deployed using AWS Code Services
